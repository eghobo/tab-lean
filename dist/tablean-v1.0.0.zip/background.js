const DEFAULT_SETTINGS = Object.freeze({
  autoCloseEnabled: false,
  delayValue: 30,
  delayUnit: "minutes",
});

const ALARM_PREFIX = "close-group:";
const closingGroupIds = new Set();
let suppressNextCreatedGroup = false;
let savedGroupsQueue = Promise.resolve();

function alarmName(groupId) {
  return `${ALARM_PREFIX}${groupId}`;
}

function groupIdFromAlarm(name) {
  if (!name.startsWith(ALARM_PREFIX)) return null;
  const id = Number(name.slice(ALARM_PREFIX.length));
  return Number.isInteger(id) ? id : null;
}

function delayToMilliseconds(settings) {
  const value = Math.max(0, Number(settings.delayValue) || 0);
  const multipliers = {
    seconds: 1000,
    minutes: 60_000,
    hours: 3_600_000,
    days: 86_400_000,
  };
  return value * (multipliers[settings.delayUnit] || multipliers.minutes);
}

async function getSettings() {
  const { settings = {} } = await chrome.storage.local.get("settings");
  return { ...DEFAULT_SETTINGS, ...settings };
}

function mutateSavedGroups(mutator) {
  const operation = savedGroupsQueue.then(async () => {
    const { savedGroups = [] } = await chrome.storage.local.get("savedGroups");
    const nextGroups = await mutator(savedGroups);
    await chrome.storage.local.set({ savedGroups: nextGroups });
    return nextGroups;
  });

  savedGroupsQueue = operation.catch(() => {});
  return operation;
}

function isRestorableUrl(url) {
  return Boolean(url) && !url.startsWith("devtools://");
}

async function snapshotGroup(groupId) {
  const [group, tabs] = await Promise.all([
    chrome.tabGroups.get(groupId),
    chrome.tabs.query({ groupId }),
  ]);

  const savedTabs = tabs
    .sort((a, b) => a.index - b.index)
    .map((tab) => ({
      title: tab.title || "Untitled tab",
      url: tab.pendingUrl || tab.url,
    }))
    .filter((tab) => isRestorableUrl(tab.url));

  if (!savedTabs.length) {
    throw new Error("This group has no pages that Chrome can restore.");
  }

  return {
    id: crypto.randomUUID(),
    title: group.title || "Untitled group",
    color: group.color,
    collapsed: group.collapsed,
    savedAt: Date.now(),
    tabs: savedTabs,
  };
}

async function closeAndSaveGroup(groupId) {
  if (closingGroupIds.has(groupId)) return;
  closingGroupIds.add(groupId);

  try {
    const savedGroup = await snapshotGroup(groupId);
    const tabs = await chrome.tabs.query({ groupId });

    // Save first. The real tabs are only removed after the recovery data exists.
    await mutateSavedGroups((groups) => [savedGroup, ...groups]);
    await chrome.tabs.remove(tabs.map((tab) => tab.id));
    await chrome.alarms.clear(alarmName(groupId));
  } finally {
    closingGroupIds.delete(groupId);
  }
}

async function scheduleGroup(groupId, settings = null) {
  const currentSettings = settings || (await getSettings());
  await chrome.alarms.clear(alarmName(groupId));

  if (!currentSettings.autoCloseEnabled) return;

  const delay = delayToMilliseconds(currentSettings);
  if (delay === 0) {
    await closeAndSaveGroup(groupId);
    return;
  }

  await chrome.alarms.create(alarmName(groupId), {
    when: Date.now() + delay,
  });
}

async function clearGroupAlarms() {
  const alarms = await chrome.alarms.getAll();
  await Promise.all(
    alarms
      .filter((alarm) => alarm.name.startsWith(ALARM_PREFIX))
      .map((alarm) => chrome.alarms.clear(alarm.name)),
  );
}

async function applySettingsToAllGroups(settings) {
  await clearGroupAlarms();
  if (!settings.autoCloseEnabled) return;

  // Keep immediate closes sequential so simultaneous storage writes cannot race.
  const groups = await chrome.tabGroups.query({});
  for (const group of groups) {
    await scheduleGroup(group.id, settings);
  }
}

async function rescheduleOnBrowserStart() {
  const settings = await getSettings();
  await applySettingsToAllGroups(settings);
}

async function restoreSavedGroup(savedGroupId) {
  const { savedGroups = [] } = await chrome.storage.local.get("savedGroups");
  const savedGroup = savedGroups.find((group) => group.id === savedGroupId);
  if (!savedGroup) throw new Error("That saved group no longer exists.");

  const currentWindow = await chrome.windows.getCurrent();
  const createdTabIds = [];

  try {
    for (const savedTab of savedGroup.tabs) {
      const tab = await chrome.tabs.create({
        active: false,
        url: savedTab.url,
        windowId: currentWindow.id,
      });
      createdTabIds.push(tab.id);
    }

    suppressNextCreatedGroup = true;
    const newGroupId = await chrome.tabs.group({
      createProperties: { windowId: currentWindow.id },
      tabIds: createdTabIds,
    });

    await chrome.tabGroups.update(newGroupId, {
      collapsed: savedGroup.collapsed,
      color: savedGroup.color,
      title: savedGroup.title,
    });

    await mutateSavedGroups((groups) =>
      groups.filter((group) => group.id !== savedGroupId),
    );

    await scheduleGroup(newGroupId);
  } catch (error) {
    suppressNextCreatedGroup = false;
    if (createdTabIds.length) {
      await chrome.tabs.remove(createdTabIds).catch(() => {});
    }
    throw error;
  }
}

async function getPopupState() {
  const [settings, groups, stored, alarms] = await Promise.all([
    getSettings(),
    chrome.tabGroups.query({}),
    chrome.storage.local.get("savedGroups"),
    chrome.alarms.getAll(),
  ]);

  const deadlines = new Map(
    alarms
      .filter((alarm) => alarm.name.startsWith(ALARM_PREFIX))
      .map((alarm) => [groupIdFromAlarm(alarm.name), alarm.scheduledTime]),
  );

  const activeGroups = await Promise.all(
    groups.map(async (group) => {
      const tabs = await chrome.tabs.query({ groupId: group.id });
      return {
        id: group.id,
        title: group.title || "Untitled group",
        color: group.color,
        tabCount: tabs.length,
        closesAt: deadlines.get(group.id) || null,
      };
    }),
  );

  return {
    activeGroups,
    savedGroups: stored.savedGroups || [],
    settings,
  };
}

chrome.runtime.onInstalled.addListener(async () => {
  const { settings, savedGroups } = await chrome.storage.local.get([
    "settings",
    "savedGroups",
  ]);
  await chrome.storage.local.set({
    settings: { ...DEFAULT_SETTINGS, ...(settings || {}) },
    savedGroups: savedGroups || [],
  });
  await rescheduleOnBrowserStart();
});

chrome.runtime.onStartup.addListener(() => {
  rescheduleOnBrowserStart().catch(console.error);
});

chrome.tabGroups.onCreated.addListener((group) => {
  if (suppressNextCreatedGroup) {
    suppressNextCreatedGroup = false;
    return;
  }
  scheduleGroup(group.id).catch(console.error);
});

chrome.tabGroups.onRemoved.addListener((group) => {
  chrome.alarms.clear(alarmName(group.id)).catch(console.error);
});

chrome.alarms.onAlarm.addListener((alarm) => {
  const groupId = groupIdFromAlarm(alarm.name);
  if (groupId === null) return;
  closeAndSaveGroup(groupId).catch((error) => {
    // The group may have been manually closed just before the timer fired.
    console.warn("TabLean could not close a scheduled group:", error.message);
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const respond = async () => {
    switch (message?.type) {
      case "getState":
        return getPopupState();

      case "closeGroup":
        await closeAndSaveGroup(Number(message.groupId));
        return getPopupState();

      case "restoreGroup":
        await restoreSavedGroup(message.savedGroupId);
        return getPopupState();

      case "deleteSavedGroup":
        await mutateSavedGroups((groups) =>
          groups.filter((group) => group.id !== message.savedGroupId),
        );
        return getPopupState();

      case "updateSettings": {
        const settings = {
          autoCloseEnabled: Boolean(message.settings.autoCloseEnabled),
          delayUnit: ["seconds", "minutes", "hours", "days"].includes(
            message.settings.delayUnit,
          )
            ? message.settings.delayUnit
            : "minutes",
          delayValue: Math.max(0, Number(message.settings.delayValue) || 0),
        };
        await chrome.storage.local.set({ settings });
        await applySettingsToAllGroups(settings);
        return getPopupState();
      }

      default:
        throw new Error("Unknown request.");
    }
  };

  respond()
    .then((data) => sendResponse({ ok: true, data }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));

  return true;
});
