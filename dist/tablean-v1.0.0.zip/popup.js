const groupColors = {
  blue: "#4285f4",
  cyan: "#24a8b8",
  green: "#33a852",
  grey: "#8a9099",
  orange: "#f08b32",
  pink: "#d965a6",
  purple: "#8e63ce",
  red: "#df4b4b",
  yellow: "#d6a514",
};

const elements = {
  autoClose: document.querySelector("#auto-close"),
  delayUnit: document.querySelector("#delay-unit"),
  delayValue: document.querySelector("#delay-value"),
  openCount: document.querySelector("#open-count"),
  openGroups: document.querySelector("#open-groups"),
  savedCount: document.querySelector("#saved-count"),
  savedGroups: document.querySelector("#saved-groups"),
  timerForm: document.querySelector("#timer-form"),
  toast: document.querySelector("#toast"),
};

let toastTimer;

function showToast(message, isError = false) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.toggle("error", isError);
  elements.toast.classList.add("visible");
  toastTimer = setTimeout(() => elements.toast.classList.remove("visible"), 2600);
}

function pluralize(count, singular) {
  return `${count} ${singular}${count === 1 ? "" : "s"}`;
}

function formatRemaining(closesAt) {
  if (!closesAt) return "";
  const milliseconds = Math.max(0, closesAt - Date.now());
  if (milliseconds < 60_000) return " · closes soon";
  const minutes = Math.ceil(milliseconds / 60_000);
  if (minutes < 60) return ` · closes in ${minutes}m`;
  const hours = Math.ceil(minutes / 60);
  if (hours < 24) return ` · closes in ${hours}h`;
  return ` · closes in ${Math.ceil(hours / 24)}d`;
}

function formatSavedTime(savedAt) {
  const date = new Date(savedAt);
  const elapsed = Date.now() - savedAt;
  if (elapsed < 60_000) return "saved just now";
  if (elapsed < 3_600_000) return `saved ${Math.floor(elapsed / 60_000)}m ago`;
  if (date.toDateString() === new Date().toDateString()) {
    return `saved ${date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
  }
  return `saved ${date.toLocaleDateString([], { month: "short", day: "numeric" })}`;
}

function makeGroupMain(group, meta) {
  const main = document.createElement("div");
  main.className = "group-main";

  const dot = document.createElement("span");
  dot.className = "color-dot";
  dot.style.setProperty("--group-color", groupColors[group.color] || groupColors.grey);

  const copy = document.createElement("div");
  copy.className = "group-copy";

  const title = document.createElement("p");
  title.className = "group-title";
  title.textContent = group.title;
  title.title = group.title;

  const detail = document.createElement("p");
  detail.className = "group-meta";
  detail.textContent = meta;

  copy.append(title, detail);
  main.append(dot, copy);
  return main;
}

function makeButton(label, className, onClick) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = className;
  button.textContent = label;
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      await onClick();
    } catch (error) {
      showToast(error.message, true);
      button.disabled = false;
    }
  });
  return button;
}

function renderEmpty(container, text) {
  const empty = document.createElement("div");
  empty.className = "empty-state";
  empty.textContent = text;
  container.replaceChildren(empty);
}

function renderState(state) {
  const { settings, activeGroups, savedGroups } = state;
  elements.autoClose.checked = settings.autoCloseEnabled;
  elements.delayValue.value = settings.delayValue;
  elements.delayUnit.value = settings.delayUnit;

  elements.openCount.textContent = activeGroups.length;
  elements.savedCount.textContent = savedGroups.length;

  if (!activeGroups.length) {
    renderEmpty(elements.openGroups, "No tab groups are open in Chrome.");
  } else {
    elements.openGroups.replaceChildren(
      ...activeGroups.map((group) => {
        const row = document.createElement("div");
        row.className = "group-row";
        row.append(
          makeGroupMain(
            group,
            `${pluralize(group.tabCount, "tab")}${formatRemaining(group.closesAt)}`,
          ),
          makeButton("Close", "button secondary", async () => {
            const nextState = await sendMessage({ type: "closeGroup", groupId: group.id });
            renderState(nextState);
            showToast(`“${group.title}” was saved and closed.`);
          }),
        );
        return row;
      }),
    );
  }

  if (!savedGroups.length) {
    renderEmpty(elements.savedGroups, "Closed groups will wait here until you restore them.");
  } else {
    elements.savedGroups.replaceChildren(
      ...savedGroups.map((group) => {
        const row = document.createElement("div");
        row.className = "group-row";
        const actions = document.createElement("div");
        actions.className = "group-actions";
        actions.append(
          makeButton("Restore", "button primary", async () => {
            const nextState = await sendMessage({
              type: "restoreGroup",
              savedGroupId: group.id,
            });
            renderState(nextState);
            showToast(`“${group.title}” restored.`);
          }),
          makeButton("×", "icon-button", async () => {
            const nextState = await sendMessage({
              type: "deleteSavedGroup",
              savedGroupId: group.id,
            });
            renderState(nextState);
            showToast("Saved group removed.");
          }),
        );
        actions.lastElementChild.setAttribute("aria-label", `Delete ${group.title}`);
        actions.lastElementChild.title = "Forget this saved group";

        row.append(
          makeGroupMain(
            group,
            `${pluralize(group.tabs.length, "tab")} · ${formatSavedTime(group.savedAt)}`,
          ),
          actions,
        );
        return row;
      }),
    );
  }
}

function sendMessage(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!response?.ok) {
        reject(new Error(response?.error || "TabLean could not complete that action."));
        return;
      }
      resolve(response.data);
    });
  });
}

elements.timerForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const submitButton = elements.timerForm.querySelector("button[type='submit']");
  submitButton.disabled = true;

  try {
    const state = await sendMessage({
      type: "updateSettings",
      settings: {
        autoCloseEnabled: elements.autoClose.checked,
        delayUnit: elements.delayUnit.value,
        delayValue: elements.delayValue.value,
      },
    });
    renderState(state);
    showToast(elements.autoClose.checked ? "Auto-close timer applied." : "Auto-close is off.");
  } catch (error) {
    showToast(error.message, true);
  } finally {
    submitButton.disabled = false;
  }
});

elements.autoClose.addEventListener("change", () => {
  elements.timerForm.requestSubmit();
});

sendMessage({ type: "getState" })
  .then(renderState)
  .catch((error) => {
    renderEmpty(elements.openGroups, "Could not read Chrome tab groups.");
    renderEmpty(elements.savedGroups, "Reload the extension and try again.");
    showToast(error.message, true);
  });
